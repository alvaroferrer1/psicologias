import { createHash } from "crypto";

/**
 * The raw session token only ever lives in the httpOnly cookie sent to the
 * browser. We persist a SHA-256 hash of it in the `Session` table so a
 * read-only leak of the database (backup, replica, injection, etc.) can't be
 * replayed as a valid `psyreport_session` cookie the way a table of raw
 * tokens could.
 */
export function hashSessionToken(rawToken: string) {
  return createHash("sha256").update(rawToken).digest("hex");
}
